import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getUser } from "@/lib/auth";
import { rateLimit } from "@/lib/rate";
import { geminiGenerate } from "@/lib/gemini";
import { cleanText, extractTextFromFile, isImageName, MAX_FILE_BYTES } from "@/lib/extract";
import { touchActivity } from "@/lib/progress";

const IMAGE_MIME: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  webp: "image/webp",
  gif: "image/gif",
};

export async function POST(req: Request) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "Belum login" }, { status: 401 });
  if (!rateLimit(`upload:${user.id}`, 10, 60_000)) {
    return NextResponse.json({ error: "Terlalu banyak upload. Coba lagi sebentar." }, { status: 429 });
  }

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return NextResponse.json({ error: "Request tidak valid" }, { status: 400 });
  }

  const titleRaw = form.get("title");
  const subjectRaw = form.get("subject");
  const textRaw = form.get("text");
  const fileRaw = form.get("file");

  let rawText = "";
  let sourceType = "text";
  let sourceName: string | null = null;
  let autoTitle = "";

  if (fileRaw instanceof File && fileRaw.size > 0) {
    const name = fileRaw.name;
    sourceName = name;
    if (fileRaw.size > MAX_FILE_BYTES) {
      return NextResponse.json({ error: "Ukuran file maksimal 4MB" }, { status: 413 });
    }
    if (isImageName(name)) {
      sourceType = "image";
      try {
        const buf = Buffer.from(await fileRaw.arrayBuffer());
        const ext = name.split(".").pop()?.toLowerCase() ?? "png";
        rawText = await geminiGenerate({
          system:
            "Anda adalah pemindai materi belajar. Ekstrak SEMUA teks dari gambar/materi berikut secara lengkap dan akurat, pertahankan judul, daftar, dan rumus dalam bentuk teks. Hasilkan HANYA teks materinya, tanpa komentar.",
          prompt: "Ekstrak teks materi dari gambar ini.",
          image: { mime: fileRaw.type || IMAGE_MIME[ext] || "image/png", data: buf.toString("base64") },
          temperature: 0.1,
          maxOutputTokens: 4096,
        });
        autoTitle = name.replace(/\.[^.]+$/, "");
      } catch (e) {
        const msg = e instanceof Error ? e.message : "Gagal membaca gambar";
        return NextResponse.json({ error: `Gagal membaca gambar: ${msg}` }, { status: 502 });
      }
    } else {
      try {
        const r = await extractTextFromFile(fileRaw);
        rawText = r.text;
        autoTitle = r.title;
        sourceType = name.toLowerCase().endsWith(".pdf")
          ? "pdf"
          : name.toLowerCase().endsWith(".docx")
            ? "docx"
            : "text";
      } catch (e) {
        const msg = e instanceof Error ? e.message : "Gagal membaca file";
        return NextResponse.json({ error: msg }, { status: 400 });
      }
    }
  } else if (typeof textRaw === "string" && textRaw.trim()) {
    rawText = cleanText(textRaw);
    sourceType = "text";
  }

  if (rawText.trim().length < 30) {
    return NextResponse.json(
      { error: "Isi materi terlalu pendek. Minimal 30 karakter." },
      { status: 400 }
    );
  }

  const title =
    (typeof titleRaw === "string" && titleRaw.trim()) || autoTitle || "Materi Baru";

  const material = await prisma.material.create({
    data: {
      userId: user.id,
      title: title.slice(0, 120),
      subject: typeof subjectRaw === "string" && subjectRaw.trim() ? subjectRaw.trim().slice(0, 60) : null,
      sourceType,
      sourceName,
      rawText: rawText.slice(0, 60000),
      status: "ANALYZING",
      step: "serap",
    },
    select: { id: true, status: true },
  });

  await touchActivity(user.id);

  return NextResponse.json({ id: material.id, status: material.status });
}

// Beri waktu cukup untuk panggilan AI di Vercel
export const maxDuration = 60;
