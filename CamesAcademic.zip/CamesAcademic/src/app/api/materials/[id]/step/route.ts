import { NextResponse } from "next/server";
import { getUser } from "@/lib/auth";
import { rateLimit } from "@/lib/rate";
import { runNextStep } from "@/lib/pipeline";

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "Belum login" }, { status: 401 });
  if (!rateLimit(`step:${user.id}`, 120, 60_000)) {
    return NextResponse.json({ error: "Terlalu banyak permintaan" }, { status: 429 });
  }

  const { id } = await params;
  try {
    const result = await runNextStep(id, user.id);
    return NextResponse.json(result);
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Terjadi kesalahan";
    const status = msg.includes("tidak ditemukan") ? 404 : msg.includes("akses") ? 403 : 500;
    return NextResponse.json({ error: msg }, { status });
  }
}

// Beri waktu cukup untuk panggilan AI di Vercel
export const maxDuration = 60;
