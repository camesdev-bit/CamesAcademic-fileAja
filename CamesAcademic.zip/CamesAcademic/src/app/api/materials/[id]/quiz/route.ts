import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getUser } from "@/lib/auth";
import { getMasteryMap } from "@/lib/progress";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "Belum login" }, { status: 401 });

  const { id } = await params;
  const material = await prisma.material.findUnique({
    where: { id },
    include: { questions: { include: { concept: true }, orderBy: { order: "asc" } } },
  });
  if (!material) return NextResponse.json({ error: "Materi tidak ditemukan" }, { status: 404 });
  if (material.userId !== user.id) {
    return NextResponse.json({ error: "Tidak punya akses" }, { status: 403 });
  }
  if (material.status !== "READY") {
    return NextResponse.json({ error: "Materi belum selesai diproses" }, { status: 409 });
  }

  const url = new URL(req.url);
  const count = Math.min(20, Math.max(1, Number(url.searchParams.get("count") ?? 10) || 10));

  const mastery = await getMasteryMap(user.id, id);
  const scoreByConcept = new Map(mastery.map((m) => [m.conceptId, m.score]));

  const sorted = [...material.questions].sort((a, b) => {
    const sa = a.conceptId ? (scoreByConcept.get(a.conceptId) ?? 0) : 50;
    const sb = b.conceptId ? (scoreByConcept.get(b.conceptId) ?? 0) : 50;
    if (sa !== sb) return sa - sb;
    if (a.difficulty !== b.difficulty) return a.difficulty - b.difficulty;
    return 0;
  });

  const picked = sorted.slice(0, count);
  return NextResponse.json({
    questions: picked.map((q) => ({
      id: q.id,
      question: q.question,
      options: JSON.parse(q.options) as string[],
      difficulty: q.difficulty,
      concept: q.concept?.name ?? null,
    })),
    total: picked.length,
  });
}

// Beri waktu cukup untuk panggilan AI di Vercel
export const maxDuration = 60;
