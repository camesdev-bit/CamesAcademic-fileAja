import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getUser } from "@/lib/auth";
import { rateLimit } from "@/lib/rate";
import { tanyaTutor, structureText, type ChatEntry } from "@/lib/ai";
import { getMasteryMap, touchActivity } from "@/lib/progress";

const LEVELS = ["sederhana", "normal", "detail", "mendalam"];

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "Belum login" }, { status: 401 });
  if (!rateLimit(`chat:${user.id}`, 20, 10 * 60_000)) {
    return NextResponse.json(
      { error: "Batas chat tercapai. Coba lagi beberapa menit lagi." },
      { status: 429 }
    );
  }

  const { id } = await params;
  const body = await req.json().catch(() => null);
  const message = String(body?.message ?? "").trim();
  const level = LEVELS.includes(body?.level) ? String(body.level) : "normal";

  if (!message || message.length > 1200) {
    return NextResponse.json({ error: "Pertanyaan tidak valid (maks 1200 karakter)" }, { status: 400 });
  }

  const material = await prisma.material.findUnique({
    where: { id },
    include: {
      summary: true,
      topics: { include: { concepts: true }, orderBy: { order: "asc" } },
      chats: { orderBy: { createdAt: "desc" }, take: 10 },
    },
  });
  if (!material) return NextResponse.json({ error: "Materi tidak ditemukan" }, { status: 404 });
  if (material.userId !== user.id) {
    return NextResponse.json({ error: "Tidak punya akses" }, { status: 403 });
  }
  if (material.status !== "READY" || !material.summary) {
    return NextResponse.json({ error: "Materi belum selesai diproses" }, { status: 409 });
  }

  const structure = structureText(
    material.topics.map((t) => ({
      title: t.title,
      description: t.description ?? undefined,
      concepts: t.concepts.map((c) => ({
        name: c.name,
        definition: c.definition ?? undefined,
        formulas: c.formulas ?? undefined,
        examples: c.examples ?? undefined,
        keyTerms: c.keyTerms ?? undefined,
      })),
    }))
  );

  const mastery = await getMasteryMap(user.id, id);
  const masteryText = mastery.map((m) => `- ${m.name}: ${m.score}`).join("\n");

  const history: ChatEntry[] = material.chats
    .slice()
    .reverse()
    .map((c) => ({ role: c.role === "user" ? "user" : "assistant", content: c.content }));

  try {
    const reply = await tanyaTutor({
      question: message,
      summary: material.summary.content,
      structure,
      mastery: masteryText,
      history,
      level,
    });

    await prisma.chatMessage.createMany({
      data: [
        { userId: user.id, materialId: id, role: "user", content: message, level },
        { userId: user.id, materialId: id, role: "assistant", content: reply, level },
      ],
    });
    await touchActivity(user.id);

    return NextResponse.json({ reply });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "AI sedang bermasalah";
    return NextResponse.json({ error: msg }, { status: 502 });
  }
}

// Beri waktu cukup untuk panggilan AI di Vercel
export const maxDuration = 60;
