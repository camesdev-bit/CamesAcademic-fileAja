// Nama file dipertahankan agar semua pemanggilan di kode tidak berubah.
// Urutan penyedia untuk teks : Gemini -> Groq -> OpenRouter
// Urutan penyedia untuk gambar: Gemini -> OpenRouter (Groq tidak punya vision)
// Tiap penyedia memutar beberapa key; key yang kena limit/rusak di-cooldown otomatis.

const COOLDOWN: Record<string, number> = {};
const RR: Record<string, number> = {};
const COOLDOWN_LIMIT_MS = 60_000;
const COOLDOWN_BAD_MS = 10 * 60_000;
const COOLDOWN_SERVER_MS = 15_000;
const COOLDOWN_OTHER_MS = 5_000;

function collectKeys(prefix: string): string[] {
  const keys: string[] = [];
  for (let i = 1; i <= 10; i++) {
    const k = process.env[`${prefix}_${i}`];
    if (k && k.trim()) keys.push(k.trim());
  }
  return keys;
}

export type GeminiOpts = {
  prompt: string;
  system?: string;
  json?: boolean;
  image?: { mime: string; data: string };
  maxOutputTokens?: number;
  temperature?: number;
  /** true = model "pintar" (struktur materi, kuis, tutor). Default: model cepat. */
  smart?: boolean;
};

/* ---------------- Gemini (API native) ---------------- */
async function callGemini(key: string, opts: GeminiOpts): Promise<string> {
  const model = opts.smart
    ? process.env.GEMINI_MODEL_SMART || "gemini-3.6-flash"
    : process.env.GEMINI_MODEL_FAST || "gemini-3.5-flash-lite";

  const parts: unknown[] = [];
  if (opts.image) parts.push({ inline_data: { mime_type: opts.image.mime, data: opts.image.data } });
  parts.push({ text: opts.prompt });

  const body: Record<string, unknown> = {
    contents: [{ role: "user", parts }],
    generationConfig: {
      temperature: opts.temperature ?? 0.7,
      ...(opts.json ? { responseMimeType: "application/json" } : {}),
      ...(opts.maxOutputTokens ? { maxOutputTokens: opts.maxOutputTokens } : {}),
    },
  };
  if (opts.system) body.systemInstruction = { parts: [{ text: opts.system }] };

  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": key },
    body: JSON.stringify(body),
    cache: "no-store",
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(`HTTP ${res.status}: ${txt.slice(0, 300)}`);
  }
  const data = await res.json();
  const text: string =
    data?.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") ?? "";
  if (!text.trim()) {
    const finish = data?.candidates?.[0]?.finishReason ?? data?.promptFeedback?.blockReason ?? "?";
    throw new Error(`Respons kosong dari Gemini (finish=${finish})`);
  }
  return text;
}

/* ---------------- Groq & OpenRouter (format OpenAI) ---------------- */
type Msg = { role: string; content: unknown };

function buildMessages(opts: GeminiOpts): Msg[] {
  const msgs: Msg[] = [];
  if (opts.system) msgs.push({ role: "system", content: opts.system });
  if (opts.image) {
    msgs.push({
      role: "user",
      content: [
        { type: "image_url", image_url: { url: `data:${opts.image.mime};base64,${opts.image.data}` } },
        { type: "text", text: opts.prompt },
      ],
    });
  } else {
    msgs.push({ role: "user", content: opts.prompt });
  }
  return msgs;
}

async function callOpenAICompat(
  url: string,
  key: string,
  model: string,
  opts: GeminiOpts,
  extraHeaders: Record<string, string> = {},
  allowJsonMode = true
): Promise<string> {
  const body: Record<string, unknown> = {
    model,
    messages: buildMessages(opts),
    temperature: opts.temperature ?? 0.7,
    max_tokens: opts.maxOutputTokens ?? 2048,
  };
  if (opts.json && allowJsonMode) body.response_format = { type: "json_object" };

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}`, ...extraHeaders },
    body: JSON.stringify(body),
    cache: "no-store",
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(`HTTP ${res.status}: ${txt.slice(0, 300)}`);
  }
  const data = await res.json();
  const text: string = data?.choices?.[0]?.message?.content ?? "";
  if (!text.trim()) {
    const finish = data?.choices?.[0]?.finish_reason ?? "?";
    throw new Error(`Respons kosong dari AI (finish=${finish})`);
  }
  return text;
}

function groqCall(key: string, opts: GeminiOpts) {
  const model = opts.smart
    ? process.env.GROQ_MODEL_SMART || "llama-3.3-70b-versatile"
    : process.env.GROQ_MODEL_FAST || "llama-3.1-8b-instant";
  return callOpenAICompat("https://api.groq.com/openai/v1/chat/completions", key, model, opts);
}

function openRouterCall(key: string, opts: GeminiOpts) {
  const model = opts.image
    ? process.env.OPENROUTER_VISION_MODEL || "google/gemma-3-27b-it:free"
    : process.env.OPENROUTER_MODEL || "meta-llama/llama-3.3-70b-instruct:free";
  return callOpenAICompat(
    "https://openrouter.ai/api/v1/chat/completions",
    key,
    model,
    opts,
    { "HTTP-Referer": "https://cames.my.id", "X-Title": "CamesAcademic" },
    false // sebagian model gratis OpenRouter tidak mendukung json_object; parseJSON menangani hasilnya
  );
}

/* ---------------- Pemilihan & rotasi ---------------- */
type Target = { id: string; provider: string; key: string; call: (key: string, opts: GeminiOpts) => Promise<string> };

function rotate<T>(arr: T[], provider: string): T[] {
  if (arr.length < 2) return arr;
  const n = (RR[provider] = ((RR[provider] ?? -1) + 1) % arr.length);
  return [...arr.slice(n), ...arr.slice(0, n)];
}

function buildTargets(opts: GeminiOpts): Target[] {
  const mk = (provider: string, prefix: string, call: Target["call"]): Target[] =>
    rotate(collectKeys(prefix), provider).map((key) => ({ id: `${provider}:${key}`, provider, key, call }));
  const gemini = mk("gemini", "GEMINI_KEY", callGemini);
  const groq = opts.image ? [] : mk("groq", "GROQ_KEY", groqCall);
  const openrouter = mk("openrouter", "OPENROUTER_KEY", openRouterCall);
  return [...gemini, ...groq, ...openrouter];
}

function cooldownFor(msg: string): number {
  const m = msg.toLowerCase();
  if (msg.includes("HTTP 429") || m.includes("quota") || m.includes("rate limit") || m.includes("resource_exhausted"))
    return COOLDOWN_LIMIT_MS;
  if (/HTTP (401|403|404)/.test(msg) || m.includes("api_key_invalid") || m.includes("api key not valid"))
    return COOLDOWN_BAD_MS;
  if (/HTTP 5\d\d/.test(msg) || m.includes("overloaded") || m.includes("unavailable")) return COOLDOWN_SERVER_MS;
  return COOLDOWN_OTHER_MS;
}

export async function geminiGenerate(opts: GeminiOpts): Promise<string> {
  const targets = buildTargets(opts);
  if (targets.length === 0) {
    throw new Error("Belum ada API key. Isi GEMINI_KEY_1.., GROQ_KEY_1.. dan/atau OPENROUTER_KEY_1.. di Vercel.");
  }
  const now = Date.now();
  let lastError = "";
  let tried = 0;
  for (const t of targets) {
    if ((COOLDOWN[t.id] || 0) > now) continue;
    tried++;
    try {
      return await t.call(t.key, opts);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      lastError = `${t.provider}: ${msg}`;
      COOLDOWN[t.id] = Date.now() + cooldownFor(msg);
    }
  }
  if (tried === 0) {
    throw new Error("Semua API key sedang kena limit. Tunggu sebentar lalu coba lagi.");
  }
  throw new Error(`AI gagal: ${lastError}`);
}

export function parseJSON<T>(raw: string): T {
  let s = raw.trim();
  s = s.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "");
  try {
    return JSON.parse(s) as T;
  } catch {
    const startObj = s.indexOf("{");
    const startArr = s.indexOf("[");
    const start = startObj === -1 ? startArr : startArr === -1 ? startObj : Math.min(startObj, startArr);
    if (start !== -1) {
      const endObj = s.lastIndexOf("}");
      const endArr = s.lastIndexOf("]");
      const end = Math.max(endObj, endArr);
      if (end > start) return JSON.parse(s.slice(start, end + 1)) as T;
    }
    throw new Error(`Respons AI bukan JSON valid: ${s.slice(0, 200)}`);
  }
}
