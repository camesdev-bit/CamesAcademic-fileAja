# CamesAcademic

AI Learning Platform — masukkan materi, AI mengubahnya jadi pengalaman belajar (ringkasan, flashcard, quiz, tutor) yang adaptif.

## Stack

- Next.js 16 (App Router) + TypeScript
- Tailwind CSS 4
- Prisma + SQLite (dev) / PostgreSQL (produksi Vercel)
- Gemini API dengan rotasi banyak key

## Setup Lokal

```bash
npm install
cp .env.example .env      # lalu isi nilai yang belum ada
npx prisma db push
npm run dev
```

Buka http://localhost:3000

## API Key Gemini (WAJIB)

Naming env key **wajib** `api_1`, `api_2`, `api_3`, ... (di Vercel: Settings → Environment Variables):

```
api_1  = AIza...
api_2  = AIza...
api_3  = AIza...
...
api_10 = AIza...
```

Semua key dibaca otomatis (`src/lib/gemini.ts`). Kalau satu key kena limit 429,
sistem langsung pindah ke key berikutnya dan meng-cooldown key limit selama 60 detik.

## Environment Lain

| Var | Fungsi |
|---|---|
| `DATABASE_URL` | `file:./dev.db` (SQLite) atau URL Postgres di Vercel |
| `SESSION_SECRET` | Secret sign JWT session (random hex 32+) |
| `GEMINI_MODEL` | Opsional, default `gemini-2.5-flash` |
| `CAMESHUB_URL` / `NEXT_PUBLIC_CAMESHUB_URL` | Link navigasi CamesHub |

## Deploy ke Vercel

1. Import repo ke Vercel.
2. Tambahkan env `api_1` ... `api_10`, `SESSION_SECRET`, `CAMESHUB_URL`.
3. **Database**: SQLite tidak persist di Vercel. Ganti provider di `prisma/schema.prisma`:
   ```prisma
   datasource db {
     provider = "postgresql"
     url      = env("DATABASE_URL")
   }
   ```
   lalu `npx prisma db push` ke Postgres (Neon/Vercel Postgres) dan set `DATABASE_URL`.

## Alur Pipeline (Async)

`EXTRACTING → ANALYZING → GENERATING → READY | FAILED`

Tiap langkah dipanggil dari client (`POST /api/materials/[id]/step`) — idempoten dan
resumable, aman untuk limit 60 detik function di Vercel:

1. Ekstraksi teks (PDF/DOCX/TXT/gambar via Gemini vision)
2. AI SERAP — struktur topik/konsep → disimpan ke DB
3. AI INTI — ringkasan yang mempertahankan konsep/rumus
4. AI PENJELAS — flashcard + soal pilihan ganda (3 level, per konsep)

## Desain

Sistem desain ada di `design-system/camesacademic/MASTER.md` (v2 "Clay-Energy 2.0").
Tampilan halaman dipisah dari data: lihat `src/components/views/*` dan `src/components/landing/*`.

## Struktur

```
src/
  app/
    (auth)/login, register      # halaman auth
    (app)/dashboard, materi,    # area login (butuh sesi)
         materi/[id], progress
    api/                        # route handlers
  components/                   # UI (LearningSpace, QuizRunner, dll)
  lib/
    gemini.ts                   # rotasi api_1..api_10 + failover
    pipeline.ts                 # step machine AI
    ai.ts                       # AI SERAP / INTI / PENJELAS
    progress.ts                 # mastery, XP, streak
prisma/schema.prisma
```

## Perintah

| Perintah | Fungsi |
|---|---|
| `npm run dev` | Dev server |
| `npm run build` | Build produksi |
| `npm run lint` | ESLint |
| `npx tsc --noEmit` | Typecheck |
| `npx prisma db push` | Sinkron skema DB |
| `npx prisma studio` | Lihat data |

## Di Luar MVP (lihat PRD §25)

Leaderboard, gamification lanjut, spaced repetition, full test, YouTube/audio,
teacher/institution, adaptive penuh.
