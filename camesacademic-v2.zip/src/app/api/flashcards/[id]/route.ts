import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getUser } from "@/lib/auth";

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "Belum login" }, { status: 401 });

  const { id } = await params;
  const body = await req.json().catch(() => null);
  if (typeof body?.mastered !== "boolean") {
    return NextResponse.json({ error: "Data tidak valid" }, { status: 400 });
  }

  const card = await prisma.flashcard.findUnique({
    where: { id },
    include: { material: { select: { userId: true } } },
  });
  if (!card) return NextResponse.json({ error: "Flashcard tidak ditemukan" }, { status: 404 });
  if (card.material.userId !== user.id) {
    return NextResponse.json({ error: "Tidak punya akses" }, { status: 403 });
  }

  await prisma.flashcard.update({ where: { id }, data: { mastered: body.mastered } });
  return NextResponse.json({ ok: true, mastered: body.mastered });
}
