import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getUser } from "@/lib/auth";
import { rateLimit } from "@/lib/rate";
import { recordAnswer } from "@/lib/progress";

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "Belum login" }, { status: 401 });
  if (!rateLimit(`answer:${user.id}`, 120, 10 * 60_000)) {
    return NextResponse.json({ error: "Terlalu banyak permintaan" }, { status: 429 });
  }

  const { id } = await params;
  const body = await req.json().catch(() => null);
  const questionId = String(body?.questionId ?? "");
  const selected = Number(body?.selected);
  if (!questionId || !Number.isInteger(selected) || selected < 0 || selected > 3) {
    return NextResponse.json({ error: "Jawaban tidak valid" }, { status: 400 });
  }

  const material = await prisma.material.findUnique({ where: { id } });
  if (!material) return NextResponse.json({ error: "Materi tidak ditemukan" }, { status: 404 });
  if (material.userId !== user.id) {
    return NextResponse.json({ error: "Tidak punya akses" }, { status: 403 });
  }

  const question = await prisma.question.findUnique({
    where: { id: questionId },
    include: { concept: true },
  });
  if (!question || question.materialId !== id) {
    return NextResponse.json({ error: "Soal tidak ditemukan" }, { status: 404 });
  }

  const options = JSON.parse(question.options) as string[];
  const bounded = Math.min(selected, options.length - 1);

  const result = await recordAnswer({
    userId: user.id,
    materialId: id,
    questionId,
    conceptId: question.conceptId,
    selected: bounded,
    correctAnswer: question.answerIndex,
  });

  return NextResponse.json({
    correct: result.correct,
    xpGain: result.xpGain,
    answerIndex: question.answerIndex,
    explanation: question.explanation,
    concept: question.concept?.name ?? null,
  });
}
