import type { Metadata } from "next";
import Landing from "@/components/landing/Landing";
import { getUser } from "@/lib/auth";

export const metadata: Metadata = {
  title: { absolute: "CamesAcademic — Belajar lebih mudah bersama AI" },
  description:
    "Upload materi, dapatkan ringkasan, flashcard, kuis, dan tutor AI dalam satu tempat. Pahami materi, latihan soal, dan lihat perkembangan belajarmu.",
};

export default async function Home() {
  const user = await getUser();
  return (
    <Landing
      signedIn={!!user}
      hubUrl={process.env.NEXT_PUBLIC_CAMESHUB_URL || "https://cames.my.id"}
    />
  );
}
