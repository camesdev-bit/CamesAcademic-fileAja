import AuthForm from "@/components/AuthForm";
import AuthShell from "@/components/AuthShell";

export default function RegisterPage() {
  return (
    <AuthShell
      eyebrow="Mulai gratis"
      title="Daftar"
      tagline="Satu akun untuk ringkasan, flashcard, quiz, dan tutor AI."
    >
      <AuthForm mode="register" />
    </AuthShell>
  );
}
