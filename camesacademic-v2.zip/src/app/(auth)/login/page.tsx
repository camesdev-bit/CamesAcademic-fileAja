import AuthForm from "@/components/AuthForm";
import AuthShell from "@/components/AuthShell";

export default function LoginPage() {
  return (
    <AuthShell
      eyebrow="Selamat datang kembali"
      title="Masuk"
      tagline="Masukkan materi → AI menyusunnya → kamu belajar sampai benar-benar paham."
    >
      <AuthForm mode="login" />
    </AuthShell>
  );
}
