import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import DashboardView from "@/components/views/DashboardView";

function startOfWeek() {
  const d = new Date();
  const day = (d.getDay() + 6) % 7;
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - day);
  return d;
}

export default async function DashboardPage() {
  const user = await requireUser();
  const weekStart = startOfWeek();

  const [materials, weekRows, totalCorrect, masteredConcepts, latest] = await Promise.all([
    prisma.material.findMany({
      where: { userId: user.id },
      orderBy: { updatedAt: "desc" },
      take: 6,
      select: { id: true, title: true, subject: true, status: true, updatedAt: true },
    }),
    prisma.answer.findMany({
      where: { userId: user.id, createdAt: { gte: weekStart } },
      select: { createdAt: true },
    }),
    prisma.answer.count({ where: { userId: user.id, correct: true } }),
    prisma.conceptMastery.count({ where: { userId: user.id, score: { gte: 70 } } }),
    prisma.material.findFirst({
      where: { userId: user.id },
      orderBy: { updatedAt: "desc" },
      select: { id: true, title: true, subject: true, status: true },
    }),
  ]);

  const weekActive = Array.from({ length: 7 }, () => false);
  for (const a of weekRows) weekActive[(a.createdAt.getDay() + 6) % 7] = true;

  const continueHref = latest
    ? latest.status === "READY"
      ? `/materi/${latest.id}`
      : `/materi/${latest.id}/proses`
    : "/materi";

  return (
    <DashboardView
      data={{
        user: { name: user.name, xp: user.xp, level: user.level, streak: user.streak },
        latest,
        continueHref,
        weekAnswers: weekRows.length,
        weeklyTarget: 30,
        weekActive,
        todayIndex: (new Date().getDay() + 6) % 7,
        totalCorrect,
        masteredConcepts,
        materials: materials.map((m) => ({
          id: m.id,
          title: m.title,
          subject: m.subject,
          status: m.status,
          dateLabel: m.updatedAt.toLocaleDateString("id-ID", { day: "numeric", month: "short" }),
        })),
      }}
    />
  );
}
