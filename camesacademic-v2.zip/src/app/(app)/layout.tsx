import Nav from "@/components/Nav";
import { requireUser } from "@/lib/auth";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();

  return (
    <div className="flex min-h-screen flex-col">
      <Nav user={{ name: user.name, xp: user.xp, level: user.level, streak: user.streak }} />
      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-6 pb-28 md:pb-12">{children}</main>
    </div>
  );
}
