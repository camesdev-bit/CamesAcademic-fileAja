import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import MateriListView from "@/components/views/MateriListView";

export default async function MateriPage() {
  const user = await requireUser();
  const materials = await prisma.material.findMany({
    where: { userId: user.id },
    orderBy: { updatedAt: "desc" },
    select: {
      id: true,
      title: true,
      subject: true,
      status: true,
      sourceType: true,
      updatedAt: true,
      _count: { select: { questions: true, flashcards: true } },
    },
  });

  return (
    <MateriListView
      materials={materials.map((m) => ({
        id: m.id,
        title: m.title,
        subject: m.subject,
        status: m.status,
        sourceType: m.sourceType,
        questions: m._count.questions,
        flashcards: m._count.flashcards,
        dateLabel: m.updatedAt.toLocaleDateString("id-ID", {
          day: "numeric",
          month: "short",
          year: "numeric",
        }),
      }))}
    />
  );
}
