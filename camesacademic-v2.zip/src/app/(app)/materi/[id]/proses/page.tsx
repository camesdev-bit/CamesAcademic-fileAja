import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import ProcessingClient from "@/components/ProcessingClient";

export default async function ProsesPage(props: PageProps<"/materi/[id]/proses">) {
  const user = await requireUser();
  const { id } = await props.params;

  const material = await prisma.material.findUnique({
    where: { id },
    select: { id: true, userId: true, title: true, status: true },
  });
  if (!material) redirect("/materi");
  if (material.userId !== user.id) redirect("/materi");
  if (material.status === "READY") redirect(`/materi/${material.id}`);

  return (
    <ProcessingClient
      id={material.id}
      title={material.title}
      initialStatus={material.status}
    />
  );
}
