import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import LearningSpace from "@/components/LearningSpace";
import type { ReportStats } from "@/components/ReportView";
import MaterialHeader from "@/components/views/MaterialHeader";

export default async function MateriDetailPage(props: PageProps<"/materi/[id]">) {
  const user = await requireUser();
  const { id } = await props.params;

  const material = await prisma.material.findUnique({
    where: { id },
    include: {
      summary: true,
      flashcards: { orderBy: { order: "asc" } },
      chats: { orderBy: { createdAt: "asc" }, take: 20 },
      _count: { select: { questions: true } },
    },
  });

  if (!material) redirect("/materi");
  if (material.userId !== user.id) redirect("/materi");
  if (material.status !== "READY" || !material.summary) redirect(`/materi/${material.id}/proses`);

  const [answers, masteryRows] = await Promise.all([
    prisma.answer.findMany({
      where: { userId: user.id, materialId: material.id },
      select: { correct: true },
    }),
    prisma.conceptMastery.findMany({
      where: { userId: user.id, concept: { topic: { materialId: material.id } } },
      include: { concept: { select: { name: true } } },
    }),
  ]);

  const correct = answers.filter((a) => a.correct).length;
  const answered = answers.length;
  const wrong = answered - correct;
  const percent = answered > 0 ? Math.round((correct / answered) * 100) : 0;

  const strengths = masteryRows.filter((m) => m.score >= 70).map((m) => m.concept.name);
  const weaknesses = masteryRows
    .filter((m) => m.score < 70)
    .map((m) => m.concept.name);

  const stats: ReportStats = {
    answered,
    correct,
    wrong,
    percent,
    strengths,
    weaknesses,
    flashcards: material.flashcards.length,
    flashcardsMastered: material.flashcards.filter((c) => c.mastered).length,
  };

  return (
    <div className="space-y-5">
      <MaterialHeader
        title={material.title}
        subject={material.subject}
        sourceType={material.sourceType}
        flashcards={material.flashcards.length}
        questions={material._count.questions}
      />

      <LearningSpace
        materialId={material.id}
        summary={material.summary.content}
        cards={material.flashcards.map((c) => ({
          id: c.id,
          front: c.front,
          back: c.back,
          mastered: c.mastered,
        }))}
        history={material.chats.map((c) => ({
          id: c.id,
          role: c.role === "user" ? "user" : "assistant",
          content: c.content,
        }))}
        stats={stats}
        mastery={masteryRows.map((m) => ({ name: m.concept.name, score: m.score }))}
      />
    </div>
  );
}
