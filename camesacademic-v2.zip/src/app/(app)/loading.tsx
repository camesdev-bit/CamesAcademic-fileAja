export default function AppLoading() {
  return (
    <div className="space-y-5" aria-busy="true" aria-label="Memuat halaman">
      <div className="space-y-2">
        <div className="skeleton h-3 w-24 rounded-full" />
        <div className="skeleton h-8 w-64 max-w-full" />
      </div>
      <div className="grid gap-4 lg:grid-cols-[1.7fr_1fr]">
        <div className="skeleton h-48 rounded-[1.5rem]" />
        <div className="skeleton h-48 rounded-[1.5rem]" />
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className="card p-4">
            <div className="skeleton h-10 w-10" />
            <div className="skeleton mt-3 h-5 w-16" />
            <div className="skeleton mt-2 h-3 w-20" />
          </div>
        ))}
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="skeleton h-20" />
        <div className="skeleton h-20" />
      </div>
    </div>
  );
}
