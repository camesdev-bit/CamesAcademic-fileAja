import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import ProgressView from "@/components/views/ProgressView";

export default async function ProgressPage() {
  const user = await requireUser();

  const [materials, answers, masteryRows] = await Promise.all([
    prisma.material.findMany({
      where: { userId: user.id, status: "READY" },
      orderBy: { updatedAt: "desc" },
      select: { id: true, title: true, subject: true },
    }),
    prisma.answer.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
      select: { createdAt: true, correct: true },
    }),
    prisma.conceptMastery.findMany({
      where: { userId: user.id },
      include: { concept: { select: { name: true, topic: { select: { materialId: true } } } } },
    }),
  ]);

  const correct = answers.filter((a) => a.correct).length;
  const acc = answers.length > 0 ? Math.round((correct / answers.length) * 100) : 0;
  const mastered = masteryRows.filter((m) => m.score >= 70).length;

  const byMaterial = new Map<string, { total: number; count: number }>();
  for (const m of masteryRows) {
    const mid = m.concept.topic.materialId;
    const cur = byMaterial.get(mid) ?? { total: 0, count: 0 };
    cur.total += m.score;
    cur.count += 1;
    byMaterial.set(mid, cur);
  }

  const days: { label: string; count: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - i);
    const next = new Date(d);
    next.setDate(next.getDate() + 1);
    const count = answers.filter((a) => a.createdAt >= d && a.createdAt < next).length;
    days.push({ label: d.toLocaleDateString("id-ID", { weekday: "short" }), count });
  }

  return (
    <ProgressView
      data={{
        user: { streak: user.streak, level: user.level, xp: user.xp },
        materialsCount: materials.length,
        answersCount: answers.length,
        accuracy: acc,
        mastered,
        days: days.map((d, i) => ({ ...d, today: i === days.length - 1 })),
        materials: materials.map((m) => {
          const agg = byMaterial.get(m.id);
          return {
            id: m.id,
            title: m.title,
            subject: m.subject,
            concepts: agg?.count ?? 0,
            avg: agg && agg.count > 0 ? Math.round(agg.total / agg.count) : null,
          };
        }),
      }}
    />
  );
}
