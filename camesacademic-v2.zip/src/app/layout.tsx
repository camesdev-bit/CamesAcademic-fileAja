import type { Metadata, Viewport } from "next";
import { Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-jakarta",
});

export const metadata: Metadata = {
  title: { default: "CamesAcademic", template: "%s · CamesAcademic" },
  description:
    "Platform belajar AI yang mengubah materi kamu menjadi pengalaman belajar interaktif dan adaptif.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#0b1f3a",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="id" className={`h-full antialiased ${jakarta.variable}`}>
      <body className="flex min-h-full flex-col text-slate-900">{children}</body>
    </html>
  );
}
