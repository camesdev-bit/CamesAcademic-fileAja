import { prisma } from "./db";
import { XP_PER_LEVEL } from "./xp";

export { XP_PER_LEVEL };
export const XP_CORRECT = 15;
export const XP_WRONG = 3;
export const XP_FLASHCARD = 2;

export function levelFromXp(xp: number) {
  return Math.floor(xp / XP_PER_LEVEL) + 1;
}

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

export async function touchActivity(userId: string) {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) return;
  const now = new Date();
  let streak = user.streak;
  if (user.lastActiveAt) {
    const diff = Math.round(
      (startOfDay(now).getTime() - startOfDay(user.lastActiveAt).getTime()) / 86_400_000
    );
    if (diff === 0) streak = user.streak;
    else if (diff === 1) streak = user.streak + 1;
    else streak = 1;
  } else {
    streak = 1;
  }
  await prisma.user.update({
    where: { id: userId },
    data: { streak, lastActiveAt: now },
  });
}

export async function awardXp(userId: string, amount: number) {
  const user = await prisma.user.update({
    where: { id: userId },
    data: { xp: { increment: amount } },
  });
  const level = levelFromXp(user.xp);
  if (level !== user.level) {
    await prisma.user.update({ where: { id: userId }, data: { level } });
  }
  return { xp: user.xp, level };
}

export async function recordAnswer(opts: {
  userId: string;
  materialId: string;
  questionId: string;
  conceptId: string | null;
  selected: number;
  correctAnswer: number;
}) {
  const correct = opts.selected === opts.correctAnswer;
  const first = await prisma.answer.findFirst({
    where: { userId: opts.userId, questionId: opts.questionId },
  });

  await prisma.answer.create({
    data: {
      userId: opts.userId,
      materialId: opts.materialId,
      questionId: opts.questionId,
      selected: opts.selected,
      correct,
    },
  });

  if (opts.conceptId) {
    const existing = await prisma.conceptMastery.findFirst({
      where: { userId: opts.userId, conceptId: opts.conceptId },
    });
    const c = (existing?.correct ?? 0) + (correct ? 1 : 0);
    const w = (existing?.wrong ?? 0) + (correct ? 0 : 1);
    const score = Math.round((c / Math.max(1, c + w)) * 100);
    if (existing) {
      await prisma.conceptMastery.update({
        where: { id: existing.id },
        data: { correct: c, wrong: w, score },
      });
    } else {
      await prisma.conceptMastery.create({
        data: { userId: opts.userId, conceptId: opts.conceptId, correct: c, wrong: w, score },
      });
    }
  }

  const xpGain = first ? 0 : correct ? XP_CORRECT : XP_WRONG;
  if (xpGain > 0) await awardXp(opts.userId, xpGain);
  await touchActivity(opts.userId);

  return { correct, xpGain };
}

export async function getMasteryMap(userId: string, materialId: string) {
  const rows = await prisma.conceptMastery.findMany({
    where: {
      userId,
      concept: { topic: { materialId } },
    },
    include: { concept: true },
  });
  return rows.map((r) => ({
    conceptId: r.conceptId,
    name: r.concept.name,
    score: r.score,
    correct: r.correct,
    wrong: r.wrong,
  }));
}
