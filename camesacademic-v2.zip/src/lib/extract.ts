import { extractText, getDocumentProxy } from "unpdf";
import mammoth from "mammoth";

export const MAX_FILE_BYTES = 8 * 1024 * 1024;

export type ExtractResult = { text: string; title: string };

export function isImageName(name: string) {
  return /\.(png|jpe?g|webp|gif)$/i.test(name);
}

export function cleanText(t: string) {
  return t
    .replace(/\r\n/g, "\n")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

export function baseTitle(fileName: string) {
  return fileName.replace(/\.[^.]+$/, "").trim() || "Materi";
}

export async function extractTextFromFile(file: File): Promise<ExtractResult> {
  const name = file.name;
  const lower = name.toLowerCase();
  const buf = Buffer.from(await file.arrayBuffer());

  if (buf.length > MAX_FILE_BYTES) {
    throw new Error("Ukuran file maksimal 8MB");
  }

  if (lower.endsWith(".pdf")) {
    const pdf = await getDocumentProxy(new Uint8Array(buf));
    const { text } = await extractText(pdf, { mergePages: true });
    return { text: cleanText(text), title: baseTitle(name) };
  }

  if (lower.endsWith(".docx")) {
    const result = await mammoth.extractRawText({ buffer: buf });
    return { text: cleanText(result.value), title: baseTitle(name) };
  }

  if (/\.(txt|md|markdown)$/.test(lower)) {
    return { text: cleanText(buf.toString("utf-8")), title: baseTitle(name) };
  }

  throw new Error("Format file belum didukung. Gunakan PDF, DOCX, TXT, atau MD.");
}
