import { prisma } from "./db";
import { buatFlashcards, buatRingkasan, buatSoal, serapMateri, structureText, type SerapTopic } from "./ai";

export type StepResult = {
  status: string;
  step: string | null;
  label: string;
  error: string | null;
};

function labelFor(status: string, step: string | null): string {
  if (status === "EXTRACTING") return "Membaca materi...";
  if (status === "ANALYZING") return "AI memahami materi...";
  if (status === "GENERATING") {
    if (step === "ringkasan") return "Menyusun ringkasan...";
    if (step === "flashcard") return "Membuat flashcard...";
    if (step === "soal") return "Membuat soal quiz...";
    return "Menyiapkan materi...";
  }
  if (status === "READY") return "Materi siap dipelajari!";
  if (status === "FAILED") return "Proses gagal";
  return "Memproses...";
}

function findConceptId(
  wanted: string | undefined,
  map: Map<string, string>
): string | null {
  if (!wanted) return null;
  const key = wanted.trim().toLowerCase();
  return map.get(key) ?? null;
}

export async function runNextStep(materialId: string, userId: string): Promise<StepResult> {
  const m = await prisma.material.findUnique({
    where: { id: materialId },
    include: {
      topics: { include: { concepts: true }, orderBy: { order: "asc" } },
      summary: true,
      flashcards: true,
      questions: true,
    },
  });

  if (!m) throw new Error("Materi tidak ditemukan");
  if (m.userId !== userId) throw new Error("Tidak punya akses");

  if (m.status === "READY") {
    return { status: "READY", step: null, label: labelFor("READY", null), error: null };
  }

  const fail = async (message: string): Promise<StepResult> => {
    await prisma.material.update({
      where: { id: m.id },
      data: { status: "FAILED", error: message.slice(0, 500) },
    });
    return { status: "FAILED", step: m.step, label: labelFor("FAILED", null), error: message };
  };

  if (!m.rawText.trim()) {
    return fail("Materi kosong. Upload ulang materi dengan isi teks.");
  }

  try {
    // STEP 1: AI SERAP — struktur materi
    if (m.topics.length === 0) {
      await prisma.material.update({
        where: { id: m.id },
        data: { status: "ANALYZING", step: "serap", error: null },
      });
      const serap = await serapMateri(m.rawText);
      const topicCount = await prisma.topic.count({ where: { materialId: m.id } });
      if (topicCount === 0) {
        let tOrder = 0;
        for (const t of serap.topics) {
          const topic = await prisma.topic.create({
            data: {
              materialId: m.id,
              title: t.title,
              description: t.description || null,
              order: tOrder++,
            },
          });
          let cOrder = 0;
          for (const c of t.concepts) {
            await prisma.concept.create({
              data: {
                topicId: topic.id,
                name: c.name,
                definition: c.definition || null,
                formulas: c.formulas || null,
                examples: c.examples || null,
                keyTerms: c.keyTerms || null,
                order: cOrder++,
              },
            });
          }
        }
      }
      if (serap.title && serap.title.trim()) {
        await prisma.material.update({
          where: { id: m.id },
          data: { title: serap.title.trim().slice(0, 120) },
        });
      }
      return { status: "ANALYZING", step: "serap", label: labelFor("ANALYZING", "serap"), error: null };
    }

    const fresh = await prisma.material.findUnique({
      where: { id: m.id },
      include: {
        topics: { include: { concepts: true }, orderBy: { order: "asc" } },
        summary: true,
        flashcards: { select: { id: true } },
        questions: { select: { id: true } },
      },
    });
    if (!fresh) throw new Error("Materi hilang");
    const topics: SerapTopic[] = fresh.topics.map((t) => ({
      title: t.title,
      description: t.description ?? undefined,
      concepts: t.concepts.map((c) => ({
        name: c.name,
        definition: c.definition ?? undefined,
        formulas: c.formulas ?? undefined,
        examples: c.examples ?? undefined,
        keyTerms: c.keyTerms ?? undefined,
      })),
    }));
    const structure = structureText(topics);
    const conceptMap = new Map<string, string>();
    for (const t of fresh.topics) {
      for (const c of t.concepts) conceptMap.set(c.name.trim().toLowerCase(), c.id);
    }

    // STEP 2: AI INTI — ringkasan
    if (!fresh.summary) {
      await prisma.material.update({
        where: { id: m.id },
        data: { status: "GENERATING", step: "ringkasan", error: null },
      });
      const summary = await buatRingkasan(m.rawText, structure);
      await prisma.summary.create({ data: { materialId: m.id, content: summary } });
      return { status: "GENERATING", step: "ringkasan", label: labelFor("GENERATING", "ringkasan"), error: null };
    }

    // STEP 3: flashcard
    if (fresh.flashcards.length === 0) {
      await prisma.material.update({
        where: { id: m.id },
        data: { status: "GENERATING", step: "flashcard", error: null },
      });
      const cards = await buatFlashcards(structure, 12);
      await prisma.flashcard.createMany({
        data: cards.map((c, i) => ({
          materialId: m.id,
          conceptId: findConceptId(c.concept, conceptMap),
          front: c.front.slice(0, 300),
          back: c.back.slice(0, 500),
          order: i,
        })),
      });
      return { status: "GENERATING", step: "flashcard", label: labelFor("GENERATING", "flashcard"), error: null };
    }

    // STEP 4: soal quiz
    if (fresh.questions.length === 0) {
      await prisma.material.update({
        where: { id: m.id },
        data: { status: "GENERATING", step: "soal", error: null },
      });
      const questions = await buatSoal(structure, 10);
      await prisma.question.createMany({
        data: questions.map((q, i) => ({
          materialId: m.id,
          conceptId: findConceptId(q.concept, conceptMap),
          difficulty: Math.min(3, Math.max(1, Math.round(q.difficulty) || 1)),
          question: q.question.slice(0, 600),
          options: JSON.stringify(q.options.slice(0, 4).map((o) => String(o).slice(0, 300))),
          answerIndex: q.answerIndex,
          explanation: q.explanation.slice(0, 800),
          order: i,
        })),
      });
      return { status: "GENERATING", step: "soal", label: labelFor("GENERATING", "soal"), error: null };
    }

    // SELESAI
    await prisma.material.update({
      where: { id: m.id },
      data: { status: "READY", step: null, error: null },
    });
    return { status: "READY", step: null, label: labelFor("READY", null), error: null };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return fail(msg);
  }
}
