import { geminiGenerate, parseJSON } from "./gemini";

export type SerapConcept = {
  name: string;
  definition?: string;
  formulas?: string;
  examples?: string;
  keyTerms?: string;
};

export type SerapTopic = {
  title: string;
  description?: string;
  concepts: SerapConcept[];
};

export type SerapResult = {
  title: string;
  topics: SerapTopic[];
};

const MATERIAL_SYS = `Anda adalah "AI SERAP MATERI", bagian dari CamesAcademic — platform belajar AI.
Tugas Anda: membaca materi mentah lalu menyusunnya menjadi struktur belajar yang akurat.
Aturan:
- Hanya gunakan informasi yang ada di materi. Jangan mengarang.
- Gunakan bahasa yang sama dengan bahasa materi (Indonesia/Inggris).
- Pilih nama materi yang singkat dan jelas.
- Maksimal 5 topik, tiap topik maksimal 4 konsep.
- definition: penjelasan konsep (1-3 kalimat).
- formulas: rumus/istilah teknis penting (opsional, pisahkan dengan "; ").
- examples: contoh dari materi (opsional).
- keyTerms: istilah penting (opsional, pisahkan dengan "; ").`;

export async function serapMateri(rawText: string): Promise<SerapResult> {
  const prompt = `Susun materi berikut menjadi struktur JSON.

Skema JSON:
{"title": string, "topics": [{"title": string, "description": string, "concepts": [{"name": string, "definition": string, "formulas": string, "examples": string, "keyTerms": string}]}]

Catatan: semua field di dalam object boleh dikosongkan dengan string "" jika tidak ada di materi.

=== MATERI ===
${rawText.slice(0, 24000)}`;

  const raw = await geminiGenerate({
    system: MATERIAL_SYS,
    prompt,
    json: true,
    temperature: 0.2,
    maxOutputTokens: 4096,
  });
  const parsed = parseJSON<SerapResult>(raw);
  if (!Array.isArray(parsed.topics) || parsed.topics.length === 0) {
    throw new Error("AI tidak menemukan struktur materi. Coba lagi.");
  }
  parsed.topics = parsed.topics.slice(0, 5);
  for (const t of parsed.topics) {
    t.concepts = (Array.isArray(t.concepts) ? t.concepts : []).slice(0, 4);
  }
  return parsed;
}

export function structureText(topics: SerapTopic[]): string {
  return topics
    .map(
      (t) =>
        `# ${t.title}${t.description ? ` — ${t.description}` : ""}\n` +
        t.concepts
          .map(
            (c) =>
              `- ${c.name}: ${c.definition || ""}` +
              (c.formulas ? ` | Rumus: ${c.formulas}` : "") +
              (c.examples ? ` | Contoh: ${c.examples}` : "")
          )
          .join("\n")
    )
    .join("\n\n");
}

export async function buatRingkasan(rawText: string, structure: string): Promise<string> {
  const system = `Anda adalah "AI INTI", pusat kecerdasan belajar CamesAcademic.
Tugas: membuat RINGKASAN materi yang MEMPERTAHANKAN makna, bukan sekadar memotong kata.
Aturan:
- Output Markdown murni (heading, bullet, tebal), tanpa pembuka/penutup.
- Pertahankan: konsep utama, definisi, rumus, hubungan antar konsep, contoh penting.
- Maksimal ±350 kata.
- Gunakan bahasa yang sama dengan materi.`;

  const prompt = `Struktur materi:
${structure}

=== MATERI MENTAH (potongan) ===
${rawText.slice(0, 18000)}`;

  const raw = await geminiGenerate({ system, prompt, temperature: 0.4, maxOutputTokens: 1600 });
  return raw.trim();
}

export type FlashcardGen = { front: string; back: string; concept: string };

export async function buatFlashcards(structure: string, count = 12): Promise<FlashcardGen[]> {
  const system = `Anda adalah "AI PENJELAS & PEMBERI SOAL" untuk CamesAcademic.
Buat flashcard pemahaman (bukan hafalan kosong) dari materi.
Aturan:
- front: pertanyaan singkat dan jelas.
- back: jawaban ringkas namun lengkap (1-3 kalimat), boleh memuat rumus.
- concept: SALIN persis nama konsep dari struktur materi yang diberikan.
- Output JSON: [{"front": string, "back": string, "concept": string}]`;

  const prompt = `Struktur materi:
${structure}

Jumlah flashcard: ${count}`;

  const raw = await geminiGenerate({ system, prompt, json: true, temperature: 0.6, maxOutputTokens: 3072 });
  const parsed = parseJSON<FlashcardGen[]>(raw);
  if (!Array.isArray(parsed) || parsed.length === 0) throw new Error("Gagal membuat flashcard.");
  return parsed.slice(0, count);
}

export type QuestionGen = {
  question: string;
  options: string[];
  answerIndex: number;
  explanation: string;
  difficulty: number;
  concept: string;
};

export async function buatSoal(structure: string, count = 10): Promise<QuestionGen[]> {
  const system = `Anda adalah "AI PENJELAS & PEMBERI SOAL" untuk CamesAcademic.
Buat soal pilihan ganda (4 opsi, tepat 1 jawaban benar) dari materi.
Aturan:
- Sebar konsep: semua konsep pada struktur mendapat minimal 1 soal bila memungkinkan.
- difficulty: 1=mudah (pengertian), 2=sedang (pemahaman), 3=sulit (penerapan/analisis). Sebar rata.
- answerIndex: index 0-3 dari opsi yang benar.
- explanation: pembahasan singkat kenapa jawabannya benar (bahasa sama dengan materi).
- concept: SALIN persis nama konsep dari struktur materi.
- Output JSON: [{"question": string, "options": [4 string], "answerIndex": number, "explanation": string, "difficulty": number, "concept": string}]`;

  const prompt = `Struktur materi:
${structure}

Jumlah soal: ${count}`;

  const raw = await geminiGenerate({ system, prompt, json: true, temperature: 0.6, maxOutputTokens: 5120 });
  const parsed = parseJSON<QuestionGen[]>(raw);
  if (!Array.isArray(parsed) || parsed.length === 0) throw new Error("Gagal membuat soal.");
  return parsed
    .filter(
      (q) =>
        Array.isArray(q.options) &&
        q.options.length >= 2 &&
        typeof q.answerIndex === "number" &&
        q.answerIndex >= 0 &&
        q.answerIndex < Math.min(q.options.length, 4)
    )
    .slice(0, count);
}

export type ChatEntry = { role: "user" | "assistant"; content: string };

export async function tanyaTutor(opts: {
  question: string;
  summary: string;
  structure: string;
  mastery: string;
  history: ChatEntry[];
  level: string;
}): Promise<string> {
  const levelMap: Record<string, string> = {
    sederhana: "Penjelasan paling sederhana, bahasa sehari-hari, analogi mudah, kalimat pendek.",
    normal: "Penjelasan normal: jelas, runtut, seperlunya contoh.",
    detail: "Penjelasan lebih detail: langkah demi langkah, contoh konkret, istilah dijelaskan.",
    mendalam: "Penjelasan mendalam: pembahasan konseptual lengkap, kaitan antar konsep, dan penjelasan kenapa konsep itu benar.",
  };
  const level = levelMap[opts.level] ?? levelMap.normal;

  const system = `Anda "AI PENJELAS & PEMBERI SOAL" (AI Tutor) CamesAcademic.
Anda memahami materi yang sedang dipelajari siswa di bawah.
Prinsip wajib: MENJELASKAN -> MEMBIMBING -> MENGECEK PEMAHAMAN. Jangan hanya memberi jawaban jadi bila siswa meminta jawaban tugas; bantu ia memahami.
Prioritaskan memakai materi di bawah. Jika pertanyaan di luar materi, katakan dengan sopan lalu jelaskan konsep terkait bila bisa.
Tingkat penjelasan: ${level}
Maksimal ±150 kata. Bahasa sama dengan bahasa pertanyaan siswa.

=== RINGKASAN MATERI ===
${opts.summary.slice(0, 6000)}

=== STRUKTUR KONSEP ===
${opts.structure.slice(0, 6000)}

=== PEMAHAMAN SISWA (0-100 per konsep) ===
${opts.mastery || "(belum ada data)"}`;

  const historyText = opts.history
    .slice(-8)
    .map((m) => `${m.role === "user" ? "Siswa" : "AI"}: ${m.content}`)
    .join("\n");

  const prompt = `${historyText ? `Riwayat percakapan:\n${historyText}\n\n` : ""}Pertanyaan siswa: ${opts.question}`;

  return (await geminiGenerate({ system, prompt, temperature: 0.6, maxOutputTokens: 1024 })).trim();
}
