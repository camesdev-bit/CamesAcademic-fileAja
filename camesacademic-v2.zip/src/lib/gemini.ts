const COOLDOWN: Record<string, number> = {};

const COOLDOWN_LIMIT_MS = 60_000;
const COOLDOWN_BAD_KEY_MS = 10 * 60_000;
const COOLDOWN_SERVER_MS = 15_000;

function getKeys(): string[] {
  const keys: string[] = [];
  for (let i = 1; i <= 10; i++) {
    const k = process.env[`api_${i}`];
    if (k && k.trim()) keys.push(k.trim());
  }
  return keys;
}

export type GeminiOpts = {
  prompt: string;
  system?: string;
  json?: boolean;
  image?: { mime: string; data: string };
  maxOutputTokens?: number;
  temperature?: number;
};

async function callGemini(key: string, model: string, opts: GeminiOpts): Promise<string> {
  const parts: unknown[] = [];
  if (opts.image) {
    parts.push({ inline_data: { mime_type: opts.image.mime, data: opts.image.data } });
  }
  parts.push({ text: opts.prompt });

  const body: Record<string, unknown> = {
    contents: [{ role: "user", parts }],
    generationConfig: {
      temperature: opts.temperature ?? 0.7,
      ...(opts.json ? { responseMimeType: "application/json" } : {}),
      ...(opts.maxOutputTokens ? { maxOutputTokens: opts.maxOutputTokens } : {}),
    },
  };
  if (opts.system) {
    body.systemInstruction = { parts: [{ text: opts.system }] };
  }

  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify(body),
      cache: "no-store",
    }
  );

  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(`HTTP ${res.status}: ${txt.slice(0, 300)}`);
  }

  const data = await res.json();
  const text: string =
    data?.candidates?.[0]?.content?.parts
      ?.map((p: { text?: string }) => p.text ?? "")
      .join("") ?? "";
  if (!text.trim()) {
    const finish = data?.candidates?.[0]?.finishReason ?? data?.promptFeedback?.blockReason ?? "?";
    throw new Error(`Respons kosong dari Gemini (finish=${finish})`);
  }
  return text;
}

export async function geminiGenerate(opts: GeminiOpts): Promise<string> {
  const keys = getKeys();
  if (keys.length === 0) {
    throw new Error("Belum ada API key Gemini. Isi env api_1, api_2, ... api_10.");
  }
  const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
  const now = Date.now();
  const ordered = [...keys].sort((a, b) => (COOLDOWN[a] || 0) - (COOLDOWN[b] || 0));

  let lastError = "";
  let tried = 0;
  for (const key of ordered) {
    if ((COOLDOWN[key] || 0) > now) continue;
    tried++;
    try {
      return await callGemini(key, model, opts);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      lastError = msg;
      if (msg.includes("429") || msg.toLowerCase().includes("quota")) {
        COOLDOWN[key] = Date.now() + COOLDOWN_LIMIT_MS;
      } else if (msg.includes("API_KEY_INVALID") || msg.includes("403") || msg.includes("401")) {
        COOLDOWN[key] = Date.now() + COOLDOWN_BAD_KEY_MS;
      } else if (msg.includes("503") || msg.toLowerCase().includes("overloaded")) {
        COOLDOWN[key] = Date.now() + COOLDOWN_SERVER_MS;
      } else {
        COOLDOWN[key] = Date.now() + 5_000;
      }
    }
  }

  if (tried === 0) {
    throw new Error("Semua API key sedang kena limit. Tunggu sebentar lalu coba lagi.");
  }
  throw new Error(`Gemini gagal: ${lastError}`);
}

export function parseJSON<T>(raw: string): T {
  let s = raw.trim();
  s = s.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "");
  try {
    return JSON.parse(s) as T;
  } catch {
    const startObj = s.indexOf("{");
    const startArr = s.indexOf("[");
    const start = startObj === -1 ? startArr : startArr === -1 ? startObj : Math.min(startObj, startArr);
    if (start !== -1) {
      const endObj = s.lastIndexOf("}");
      const endArr = s.lastIndexOf("]");
      const end = Math.max(endObj, endArr);
      if (end > start) {
        return JSON.parse(s.slice(start, end + 1)) as T;
        }
    }
    throw new Error(`Respons AI bukan JSON valid: ${s.slice(0, 200)}`);
  }
}
