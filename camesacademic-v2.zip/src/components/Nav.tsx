"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { xpProgress } from "@/lib/xp";
import Logo from "./Logo";
import ProgressRing from "./ProgressRing";
import { BookIcon, ChartIcon, FlameIcon, HomeIcon, HubIcon, LogoutIcon } from "./icons";

export type NavUser = {
  name: string;
  xp: number;
  level: number;
  streak: number;
};

const ITEMS = [
  { href: "/dashboard", label: "Beranda", icon: HomeIcon },
  { href: "/materi", label: "Materi", icon: BookIcon },
  { href: "/progress", label: "Progress", icon: ChartIcon },
];

function hubUrl() {
  return process.env.NEXT_PUBLIC_CAMESHUB_URL || "https://cames.my.id";
}

export default function Nav({ user }: { user: NavUser }) {
  const pathname = usePathname();
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function logout() {
    setBusy(true);
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  }

  const active = (href: string) => pathname === href || pathname.startsWith(href + "/");
  const initial = user.name.trim().charAt(0).toUpperCase() || "S";
  const xp = xpProgress(user.xp);

  return (
    <>
      <header className="glass sticky top-0 z-40 border-b border-[#e4ecfc] shadow-[0_6px_24px_-16px_rgba(15,23,42,0.25)]">
        <div className="mx-auto flex h-16 w-full max-w-5xl items-center justify-between gap-3 px-4">
          <div className="hidden sm:block">
            <Logo href="/dashboard" />
          </div>
          <div className="sm:hidden">
            <Logo href="/dashboard" compact />
          </div>

          <nav
            className="hidden items-center gap-1 rounded-2xl bg-slate-100/80 p-1 ring-1 ring-inset ring-slate-200/60 md:flex"
            aria-label="Navigasi utama"
          >
            {ITEMS.map((it) => {
              const Icon = it.icon;
              const isActive = active(it.href);
              return (
                <Link
                  key={it.href}
                  href={it.href}
                  aria-current={isActive ? "page" : undefined}
                  className={`flex min-h-9 items-center gap-2 rounded-xl px-3.5 text-sm font-bold transition ${
                    isActive
                      ? "bg-white text-brand shadow-[0_1px_2px_rgba(15,23,42,0.08),0_4px_10px_-6px_rgba(15,23,42,0.2)]"
                      : "text-slate-600 hover:text-navy"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {it.label}
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-2">
            <span
              className="flex min-h-9 items-center gap-1.5 rounded-xl bg-orange-50 px-2.5 text-xs font-extrabold text-orange-700 ring-1 ring-inset ring-orange-200/70"
              title="Streak belajar"
            >
              <FlameIcon className="h-4 w-4" />
              {user.streak}
              <span className="sr-only"> hari beruntun</span>
            </span>

            <div className="flex items-center gap-2.5 rounded-2xl bg-white py-1 pl-1 pr-3 ring-1 ring-inset ring-[#e4ecfc]">
              <ProgressRing
                pct={xp.pct}
                size={34}
                stroke={4}
                label={`Level ${user.level}, ${xp.pct}% menuju level berikutnya`}
              >
                <span className="text-[11px] font-extrabold text-navy">{user.level}</span>
              </ProgressRing>
              <div className="hidden text-xs leading-tight sm:block">
                <div className="max-w-[7rem] truncate font-extrabold text-navy">{user.name}</div>
                <div className="font-semibold text-slate-600">
                  Lv {user.level} · {user.xp} XP
                </div>
              </div>
              <span className="grid h-7 w-7 place-items-center rounded-lg bg-gradient-to-br from-brand to-brand-700 text-xs font-extrabold text-white sm:hidden">
                {initial}
              </span>
            </div>

            <a
              href={hubUrl()}
              aria-label="Buka CamesHub"
              className="hidden h-10 w-10 place-items-center rounded-xl text-slate-600 transition hover:bg-slate-100 hover:text-brand md:grid"
            >
              <HubIcon className="h-[18px] w-[18px]" />
            </a>
            <button
              onClick={logout}
              disabled={busy}
              aria-label="Keluar dari akun"
              className="grid h-10 w-10 place-items-center rounded-xl text-slate-600 transition hover:bg-red-50 hover:text-red-600"
            >
              <LogoutIcon className="h-[18px] w-[18px]" />
            </button>
          </div>
        </div>
      </header>

      <nav
        className="fixed inset-x-3 bottom-3 z-40 md:hidden"
        style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
        aria-label="Navigasi utama"
      >
        <div className="glass mx-auto grid max-w-md grid-cols-4 gap-1 rounded-[1.4rem] border border-white/70 p-1.5 shadow-dock ring-1 ring-slate-900/5">
          {ITEMS.map((it) => {
            const Icon = it.icon;
            const isActive = active(it.href);
            return (
              <Link
                key={it.href}
                href={it.href}
                aria-current={isActive ? "page" : undefined}
                className={`flex min-h-14 flex-col items-center justify-center gap-0.5 rounded-2xl text-[11px] font-bold transition ${
                  isActive
                    ? "bg-gradient-to-b from-brand to-brand-700 text-white shadow-[0_8px_16px_-8px_rgba(37,99,235,0.8)]"
                    : "text-slate-600 active:bg-slate-100"
                }`}
              >
                <Icon className="h-5 w-5" />
                {it.label}
              </Link>
            );
          })}
          <a
            href={hubUrl()}
            className="flex min-h-14 flex-col items-center justify-center gap-0.5 rounded-2xl text-[11px] font-bold text-slate-600 transition active:bg-slate-100"
          >
            <HubIcon className="h-5 w-5" />
            CamesHub
          </a>
        </div>
      </nav>
    </>
  );
}
