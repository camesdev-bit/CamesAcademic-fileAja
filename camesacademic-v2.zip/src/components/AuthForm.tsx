"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { EyeIcon, EyeOffIcon } from "./icons";

export default function AuthForm({ mode }: { mode: "login" | "register" }) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [showPw, setShowPw] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const res = await fetch(`/api/auth/${mode}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(data.error || "Terjadi kesalahan");
        return;
      }
      router.push("/dashboard");
      router.refresh();
    } catch {
      setError("Koneksi gagal. Coba lagi.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      {mode === "register" && (
        <div>
          <label htmlFor="auth-name" className="mb-1.5 block text-sm font-bold text-slate-700">Nama</label>
          <input
            className="input"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Nama kamu"
            id="auth-name"
            autoComplete="name"
            required
            minLength={2}
          />
        </div>
      )}
      <div>
        <label htmlFor="auth-email" className="mb-1.5 block text-sm font-bold text-slate-700">Email</label>
        <input
          className="input"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="nama@email.com"
            id="auth-email"
          autoComplete="email"
          required
        />
      </div>
      <div>
        <label htmlFor="auth-password" className="mb-1.5 block text-sm font-bold text-slate-700">Password</label>
        <div className="relative">
          <input
            className="input pr-12"
            type={showPw ? "text" : "password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Minimal 6 karakter"
            id="auth-password"
            autoComplete={mode === "login" ? "current-password" : "new-password"}
            required
            minLength={6}
          />
          <button
            type="button"
            onClick={() => setShowPw((v) => !v)}
            aria-label={showPw ? "Sembunyikan password" : "Tampilkan password"}
            aria-pressed={showPw}
            className="absolute right-0.5 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-xl text-slate-500 transition hover:bg-slate-100 hover:text-navy"
          >
            {showPw ? <EyeOffIcon className="h-5 w-5" /> : <EyeIcon className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {error && (
        <p role="alert" className="rounded-xl bg-red-50 px-3.5 py-2.5 text-sm font-semibold text-red-700 ring-1 ring-inset ring-red-200">
          {error}
        </p>
      )}

      <button type="submit" className="btn btn-primary w-full py-3" disabled={busy}>
        {busy ? (
          <>
            <span className="spinner" /> Memproses...
          </>
        ) : mode === "login" ? (
          "Masuk"
        ) : (
          "Daftar"
        )}
      </button>

      <p className="text-center text-sm font-medium text-slate-600">
        {mode === "login" ? (
          <>
            Belum punya akun?{" "}
            <Link href="/register" className="font-extrabold text-brand underline-offset-2 hover:underline">
              Daftar
            </Link>
          </>
        ) : (
          <>
            Sudah punya akun?{" "}
            <Link href="/login" className="font-extrabold text-brand underline-offset-2 hover:underline">
              Masuk
            </Link>
          </>
        )}
      </p>
    </form>
  );
}
