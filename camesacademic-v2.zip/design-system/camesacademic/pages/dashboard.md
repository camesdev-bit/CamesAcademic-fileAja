# Page Override — Dashboard

Lewati Master untuk poin ini:

- **Hero:** full-bleed navy gradient (PRD §28) diperbolehkan sebagai satu-satunya hero besar; di dalamnya deco-grid opacity ≤50%.
- **Stat tiles:** grid 2/3/6 kolom, ikon tile 36px bg brand/10; value 18px extra-bold (lebih tinggi dari label 11px uppercase).
- **CTA utama:** persis satu `btn-primary` ("Upload Materi") di area atas; aksi lain ghost/white.
- Sisanya ikuti Master (radius 20px, press 0.97, kontras slate-500).
