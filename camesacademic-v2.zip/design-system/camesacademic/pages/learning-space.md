# Page Override — Learning Space (/materi/[id])

Lewati Master untuk poin ini:

- **Tab bar:** segmented control pill (bg muted `#F1F5FD`, aktif putih + shadow tipis), sticky top-16 z-30, scroll horizontal di mobile tanpa scrollbar — bukan nav bawah (bottom-nav-limit hanya untuk top-level).
- **Flashcard:** depan putih/hitam, belakang gradient navy (satu-satunya gradient sekunder di app); flip = transform (bukan width/height); progress angka wajib "Kartu n/N".
- **Quiz:** satu primary CTA per state (Lanjut/Selesai); jawaban benar/salah = warna + ikon check/X + label teks; difficulty chip selalu ber-ikon teks.
- **Chat:** avatar AI 28px gradient; user bubble kanan brand-gradient; composer sticky di bawah list, send button icon-only wajib aria-label (Master §5).
- Sisanya ikuti Master.
