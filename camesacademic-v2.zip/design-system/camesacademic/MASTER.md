# CamesAcademic — Master Design System

> Sumber: `ui-ux-pro-max` CSV queries (manual BM25-equivalent, Python unavailable).
> Query domain: `product` (education/learning/flashcard/quiz), `color`, `typography`,
> `style`, `ui-reasoning`, `ux-guidelines`, `stack=nextjs`.
> Hierarki: file ini = Global Source of Truth. Override per halaman di `pages/*.md`.

## 1. Product Match

| Match | Confidence | Pattern | Style Priority |
|---|---|---|---|
| Flashcard & Study Tool (products.csv #103) | HIGH | Feature-Rich Showcase + Demo | Claymorphism + Micro-interactions |
| Online Course/E-learning (#43) | HIGH | Feature-Rich + Social Proof | Claymorphism + Vibrant & Block-based |
| Trivia & Quiz Game (#121) | HIGH | Feature-Rich Showcase | Vibrant & Block-based + Micro-interactions |
| Educational App (#9) | MEDIUM | Feature-Rich Showcase | Claymorphism + Micro-interactions |

Reasoning (`ui-reasoning.csv`):
- #103: colors "Playful primary + correct green + incorrect red + progress blue"; typography "Playful + Rounded + Friendly"; effects "Multi-layer shadows + Spring bounce + Soft press 200ms"; **anti-pattern: inconsistent styling + poor contrast**.
- #121: colors "Energetic blue + correct green + incorrect red + leaderboard gold"; **anti-pattern: muted colors + low energy**.
- #9: effects "Soft press (200ms) + fluffy elements"; **constraint gamification → add-progress-animation**; anti-pattern: dark mode default + jargon.
- #43: **must-have progress-tracking**; anti-pattern: boring design + no gamification.

**Resolved direction:** *Friendly Clay-Energy* — lembut & membulat (clay), energik pada feedback (quiz/XP), tanpa jargon, progres selalu terlihat. PRD §28 identitas biru memegang `primary`.

## 2. Color Tokens (colors.csv #121 + #9, diselaraskan PRD §28)

| Token | Hex | Source | Use |
|---|---|---|---|
| `--color-brand` primary | `#2563EB` | #121 primary = PRD biru | CTA, active, progress |
| `--color-brand-light` | `#60A5FA` | turunan | gradient end, hover |
| on-primary | `#FFFFFF` | #121 | teks di atas brand |
| accent gold | `#F59E0B` | #121 accent | XP, reward, streak |
| correct green | `#16A34A` | #103 accent / feedback green | benar, dikuasai |
| incorrect red | `#DC2626` | #121 destructive | salah, error |
| background | `#EFF6FF` | #121 background | body (blue tint) |
| surface / card | `#FFFFFF` | #121 card | cards |
| muted | `#F1F5FD` | #121 muted | chips, ghost |
| foreground | `#0F172A` | #121 foreground | teks utama |
| muted-fg | `#475569` | #121 muted-fg | teks sekunder (≥4.5:1) |
| border | `#E4ECFC` | #121 border | pembatas lembut |
| ring | `#2563EB` | #121 ring | focus ring |
| navy hero | `#0B1F3A → #1E40AF` | PRD §28 | hero/header gradient |

**Hard rules:** kontras teks ≥4.5:1 (slate-400 `#94a3b8` = 2.8:1 **DILARANG** untuk teks informatif → slate-500 `#475569`); feedback tidak boleh color-only (wajib ikon/teks); tanpa dark mode di MVP.

## 3. Typography (typography.csv #13 "Friendly SaaS")

- **Plus Jakarta Sans** variable 200–800, single family, mood: friendly+modern+approachable.
- Via `next/font/google` (stack rule nextjs #22), `display: swap`, variable `--font-jakarta`, dipasang sekali di root layout (#23).
- Skala: body 16px; label ≥12px; heading 700–800; eyebrow 12px uppercase 0.14em.
- Line-height 1.5–1.75 body; input **16px** (cegah auto-zoom iOS).

## 4. Style & Effects

- **Radius:** cards 20px, buttons/inputs 14px, chips penuh. (Clay: 16–24px, tanpa sudut tajam.)
- **Shadow:** multi-layer lembut (1px akar + diffus wide), tanpa border keras — border `#E4ECFC` 1px tipis.
- **Micro-interactions:** hover lift −2px 160ms; **press scale 0.97–0.98 ~150–200ms ease-out** (soft press); tanpa layout shift.
- **Progress animation:** width transition 500ms pada semua progress bar/ring (wajib, gamification constraint).
- **Motion tokens:** 150ms state · 200ms press · 300ms content · stagger 40–60ms; `transform/opacity` saja; hormati `prefers-reduced-motion`.
- Ikon: satu keluarga vector (stroke konsisten 1.75), tanpa emoji; ukuran token 16/18/20/24.

## 5. Interaction (Quick Reference §1–§2, CRITICAL)

- Touch target ≥44px semua kontrol; jarak antar kontrol ≥8px.
- Focus visible 2px ring `#2563EB` offset 2 — semua kontrol bisa di-tab.
- Icon-only wajib `aria-label`; error `role="alert"`; loading → `disabled` + spinner; empty state = pesan + aksi; double-submit dicegah.
- Bottom nav ≤5 item, icon+label, active ter-highlight.

## 6. Anti-Patterns (dilarang)

1. slate-400 sebagai teks informasi / kontras <4.5:1.
2. Color-only (benar/salah hanya merah-hijau tanpa ikon).
3. Layout shift (CLS) — tanpa dimensi/placeholder.
4. Emoji sebagai ikon; ikon campur style.
5. Hover-only interaction; kontrol tampak bisa diklik tapi diam.
6. Satu durasi untuk semua transisi; animasi dekoratif berulang.
7. Placeholder sebagai satu-satunya label input.
8. Progress tanpa angka/persentase.
9. Satu primary CTA per layar (lainnya subordinate).
10. Teks <12px untuk informasi; teks <16px pada input.

## 7. Stack Rules (stacks/nextjs.csv)

App Router ✓ · route groups ✓ · `loading.tsx` untuk state rute ✓ · `next/font` variable ✓ ·
`next/image` width/height ✓ · `next/dynamic` komponen berat ✓ · skeleton reserve space ✓ ·
config Next 16 (`cacheComponents`, `remotePatterns`) ✓.


---

## 9. Upgrade v2 — "Clay-Energy 2.0" (Okt 2026)

Evolusi visual, identitas biru/navy + Plus Jakarta Sans **tidak berubah**.

**Token baru** (`globals.css` → `@theme`): `--color-brand-700 #1D4ED8` (sebelumnya dipakai tapi belum terdefinisi),
`--color-gold #F59E0B` / `--color-gold-soft #FEF3C7` (XP & level), `--shadow-float`, `--shadow-dock`.

**Perubahan arah**
- Header app: dari navy solid → **glass putih** (blur 16px) + segmented nav pill; navy tetap untuk hero card.
- Mobile nav: dari bar penuh → **floating dock** (rounded 22px, safe-area, aktif = pill biru).
- Level/XP: cincin progres (`ProgressRing`) di header + kartu level emas di dashboard (XP_PER_LEVEL = 500).
- Dashboard: bento 2 kolom — hero "lanjutkan belajar" + cincin target mingguan, kartu level + strip aktivitas 7 hari.
- Flashcard: **flip 3D transform** (sesuai aturan page override), navigasi panah keyboard.
- Quiz: progres **bersegmen** per soal (hijau benar / kuning salah), opsi dengan ikon + label teks "Benar"/"Jawabanmu" (tidak color-only), animasi shake/pop (hormati reduced-motion).
- Auth: layout split (panel brand + form), tombol tampilkan/sembunyikan password.
- Landing: aurora hero, kartu melayang (streak/XP), strip fakta produk, fitur bento, timeline cara kerja.
- Loading: skeleton shimmer menggantikan `animate-pulse`.

**Aturan teknis baru**
- Kelas komponen (`.card`, `.btn*`, `.input`, `.glass`, …) berada di `@layer components` supaya utility Tailwind
  (`hidden`, `border-0`, dst.) bisa menimpanya. Sebelumnya `.btn` meng-override `hidden` sehingga tombol "Masuk" selalu tampil.
- Grid satu kolom pada daftar berisi teks `truncate` wajib `grid-cols-1` (cegah overflow horizontal di mobile).
- Warna avatar pelajaran & badge status dipusatkan di `src/lib/subject.ts`.
- Halaman server dipisah: data di `page.tsx`, tampilan di `components/views/*` (presentational, mudah di-preview).
